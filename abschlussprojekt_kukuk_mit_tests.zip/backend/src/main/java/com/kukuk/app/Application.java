package com.kukuk.app;

public class Application {
    public static void main(String[] args) {
        System.out.println("Hello Kukuk DevOps!");
    }
}