package com.kukuk.app;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ApplicationTest {
    @Test
    void testStartup() {
        assertTrue(true, "Provisorischer Test läuft");
    }
}