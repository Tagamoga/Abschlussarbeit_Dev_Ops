# Kukuk DevOps Abschlussprojekt

Dieses Projekt beinhaltet eine Beispielanwendung mit CI/CD und Kubernetes Deployment.